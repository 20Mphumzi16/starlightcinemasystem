package za.ac.cput.domain;

public enum ShowStatus {
    SCHEDULED,
    RUNNING,
    CANCELLED,
}
