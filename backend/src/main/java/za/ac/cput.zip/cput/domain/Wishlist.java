package za.ac.cput.domain;

import jakarta.annotation.Nullable;
import jakarta.persistence.*;


import java.util.List;
import java.util.Objects;
import java.util.Set;


@Entity
public class Wishlist{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne(cascade =CascadeType.ALL)
    private Customer customer;
    @ManyToMany(fetch = FetchType.EAGER,cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinTable(
            name = "wishList_shows",
            joinColumns = @JoinColumn(name = "wishList_id"),
            inverseJoinColumns = @JoinColumn(name = "show_id")
    )
    @Nullable
    private Set<Show> showSet;


    public Wishlist() {
    }
    protected Wishlist(Builder builder){
        this.id=builder.id;
        this.customer=builder.customer;
        this.showSet=builder.showSet;
    }

    public Long getId() {
        return id;
    }


    public Customer getCustomer() {
        return customer;
    }

    public Set<Show> getShowSet() {
        return showSet;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Wishlist wishlist = (Wishlist) o;
        return Objects.equals(id, wishlist.id) && Objects.equals(customer, wishlist.customer) && Objects.equals(showSet, wishlist.showSet) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, customer, showSet);
    }

    @Override
    public String toString() {
        return "WishList{" +
                "id=" + id +
                ", customer=" + customer +
                ", showSet=" + showSet +
                '}';
    }

    public static class Builder{

        private Long id;
        private Customer customer;
        private Set<Show> showSet;

        public Builder() {
        }

        public Builder setId(Long id) {
            this.id = id;
            return this;
        }



        public Builder setCustomer(Customer customer) {
            this.customer = customer;
            return this;
        }

        public Builder setShows(Set<Show> showSet) {
            this.showSet = showSet;
            return this;
        }

        public Builder copy(Wishlist wishList){
            this.id=wishList.id;
            this.customer=wishList.customer;
            this.showSet=wishList.showSet;
            return this;
        }
        public Wishlist build(){
            return new Wishlist(this);
        }
    }
}
