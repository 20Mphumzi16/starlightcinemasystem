package za.ac.cput.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import za.ac.cput.domain.Show;
import za.ac.cput.domain.Wishlist;
import za.ac.cput.service.ShowService.ShowService;
import za.ac.cput.service.WishlistService.WishlistService;

@Component
public class AddToWishlistService {

    private final ShowService showService;
    private final WishlistService wishlistService;

    @Autowired
    public AddToWishlistService(WishlistService wishListService, ShowService showService) {
        this.wishlistService = wishListService;
        this.showService = showService;
    }

    public Wishlist addShowToWishlist(Long wishlistId, Long showId) {
        // Retrieve the wishlist and show
        Wishlist wishlist = wishlistService.read(wishlistId);
        System.out.println("Before adding to wishlist operation: " + wishlist);
        Show show = showService.read(showId);
        System.out.println("Before adding to wishlist operation: " + show);

        if (wishlist != null && show != null) {
            // Check if the show  is already in the wishlist
            assert wishlist.getShowSet() != null;
            for (Show showInSet : wishlist.getShowSet()) {
                if (showInSet.getId().equals(showId)) {
                    System.out.println("Movie already in wishlist");
                    return wishlist;
                }
            }

            // show not found in the wishlist, add a new entry
            Show newShow = new Show.ShowBuilder()
                    .copy(show)
                    .build();
            wishlist.getShowSet().add(newShow);

            System.out.println("Comic book added to wishlist: " + newShow);

            // Update the wishlist with the new comic book and updated date
            Wishlist updatedWishlist = new Wishlist.Builder()
                    .copy(wishlist)
                    .build();

            return wishlistService.update(updatedWishlist);
        }

        return null;
    }



}
