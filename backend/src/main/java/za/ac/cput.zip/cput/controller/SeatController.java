package za.ac.cput.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.domain.Seat;
import za.ac.cput.service.SeatService.SeatService;

import java.util.List;
@CrossOrigin("localhost:3000")
@RestController
@RequestMapping("/seat")
public class SeatController {

    private final SeatService seatService;
    @Autowired
    public SeatController(SeatService seatService) {
        this.seatService = seatService;
    }

    @PostMapping("/create")
    public Seat create(@RequestBody Seat seat) {
        return seatService.create(seat);
    }

    @GetMapping("/read/{id}")
    public Seat read(@PathVariable Long id) {
        return seatService.read(id);

    }

    @PostMapping("/update")
    public Seat update(@RequestBody Seat seat) {
        return seatService.update(seat);
    }

    @DeleteMapping("/delete/{id}")
    public boolean delete(@PathVariable Long id) {
        return seatService.delete(id);
    }

    @GetMapping("/get-all")
    public List<Seat> getAll() {
        return seatService.getAllSeats();
    }
}
