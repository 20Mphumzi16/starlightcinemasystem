package za.ac.cput.domain;

public enum BookingStatus {
    Confirmed,
    Canceled,
}
