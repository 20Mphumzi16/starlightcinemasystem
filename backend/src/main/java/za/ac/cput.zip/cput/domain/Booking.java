package za.ac.cput.domain;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne( optional = false ,cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "show_id", nullable = false)
    private Show show;

    @ManyToOne( optional = false,cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "user_id", nullable = false)
    private Customer customer;

    @OneToMany(mappedBy = "booking", cascade = {CascadeType.PERSIST, CascadeType.MERGE}, orphanRemoval = true)
    private Set<SeatReservation> reservedSeats = new HashSet<>();

    @Enumerated(EnumType.STRING)
    private BookingStatus status;

    private LocalDateTime createdAt;

    protected Booking() {
        // JPA requires a no-arg constructor
    }

    private Booking(BookingBuilder builder) {
        this.id = builder.id;
        this.show = builder.show;
        this.customer = builder.customer;
        this.status = builder.status;
        this.createdAt = builder.createdAt;
    }

    public Long getId() {
        return id;
    }

    public Show getShow() {
        return show;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Set<SeatReservation> getReservedSeats() {
        return reservedSeats;
    }

    public BookingStatus getStatus() {
        return status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Booking)) return false;
        Booking booking = (Booking) o;
        return Objects.equals(id, booking.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Booking{" +
                "id=" + id +
                ", show=" + show +
                ", customer=" + customer +
                ", status=" + status +
                ", createdAt=" + createdAt +
                '}';
    }

    public static class BookingBuilder {
        private Long id;
        private Show show;
        private Customer customer;
        private BookingStatus status;
        private LocalDateTime createdAt;

        public BookingBuilder setId(Long id) {
            this.id = id;
            return this;
        }

        public BookingBuilder setShow(Show show) {
            this.show = show;
            return this;
        }

        public BookingBuilder setCustomer(Customer customer) {
            this.customer = customer;
            return this;
        }

        public BookingBuilder setStatus(BookingStatus status) {
            this.status = status;
            return this;
        }

        public BookingBuilder setCreatedAt(LocalDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public BookingBuilder copy(Booking booking){
            this.id=booking.id;
            this.show=booking.show;
            this.customer=booking.customer;
            this.status=booking.status;
            this.createdAt=booking.createdAt;
            return this;
        }

        public Booking build() {
            return new Booking(this);
        }
    }
}
