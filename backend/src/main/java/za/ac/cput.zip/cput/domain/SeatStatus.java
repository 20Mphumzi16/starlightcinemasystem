package za.ac.cput.domain;

public enum SeatStatus {
    RESERVED,
    CONFIRMED,
    RELEASED
}
